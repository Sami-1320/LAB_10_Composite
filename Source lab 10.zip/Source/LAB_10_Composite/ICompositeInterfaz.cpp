// Fill out your copyright notice in the Description page of Project Settings.


#include "ICompositeInterfaz.h"

// Add default functionality here for any IICompositeInterfaz functions that are not pure virtual.
